#ifndef _mpeg_types_h_
#define _mpeg_types_h_

#include <inttypes.h>
#include <stdint.h>
#include <stddef.h>

#define PTS_NO_VALUE INT64_MIN //(int64_t)0x8000000000000000L

#endif /* !_mpeg_types_h_ */
