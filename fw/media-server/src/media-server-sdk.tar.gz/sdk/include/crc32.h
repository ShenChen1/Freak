#ifndef _crc32_h_
#define _crc32_h_

unsigned int crc32(unsigned int crc, const unsigned char *buffer, unsigned int size);

#endif /* !_crc32_h_ */
