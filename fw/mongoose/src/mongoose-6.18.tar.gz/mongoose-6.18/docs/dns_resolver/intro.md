---
title: Async DNS resolver
items:
  - { name: overview.md }
  - { name: ../c-api/resolv.h/ }
---
