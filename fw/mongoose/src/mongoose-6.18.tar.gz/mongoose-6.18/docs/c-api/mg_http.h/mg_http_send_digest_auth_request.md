---
title: "mg_http_send_digest_auth_request()"
decl_name: "mg_http_send_digest_auth_request"
symbol_kind: "func"
signature: |
  void mg_http_send_digest_auth_request(struct mg_connection *c,
                                        const char *domain);
---

Sends 401 Unauthorized response. 

