---
title: "mbuf_init()"
decl_name: "mbuf_init"
symbol_kind: "func"
signature: |
  void mbuf_init(struct mbuf *, size_t initial_capacity);
---

Initialises an Mbuf.
`initial_capacity` specifies the initial capacity of the mbuf. 

