---
title: "mbuf_move()"
decl_name: "mbuf_move"
symbol_kind: "func"
signature: |
  void mbuf_move(struct mbuf *from, struct mbuf *to);
---

Moves the state from one mbuf to the other. 

