---
title: "mg_parse_dns()"
decl_name: "mg_parse_dns"
symbol_kind: "func"
signature: |
  int mg_parse_dns(const char *buf, int len, struct mg_dns_message *msg);
---

Low-level: parses a DNS response. 

