
#ifndef __RKAIQ_TYPES_ALGO_AGIC_INT_H__
#define __RKAIQ_TYPES_ALGO_AGIC_INT_H__

#include "rk_aiq_types_algo_agic.h"

#endif//__RKAIQ_TYPES_ALGO_AGIC_INT_H__